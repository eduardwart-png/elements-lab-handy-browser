# ELEMENTS LABS — Telegram-Testversion

**Aktueller Stand: siehe `BERICHT.md` (v3, 23.10.2026) — die Angaben unten zu 19 Varianten/Schemagrafiken sind überholt.** Früher: Lokal benutzbar und im Browser geprüft; noch keine echte Telegram-Abnahme, keine öffentliche HTTPS-Bereitstellung und kein Versand von Bestellungen.

## Start

Python 3.9 oder neuer und Node für den optionalen JavaScript-Test; keine Installation von Paketen erforderlich.

```sh
cd miniapp
python3 server.py --port 8766
# Im Browser: http://127.0.0.1:8766/
```

Auf dem Mac kann alternativ `Shop-Vorschau.command` gestartet werden. Der Server ist ausschließlich an 127.0.0.1 gebunden. Es gibt keinen Autostart-/Dauerbetriebsauftrag. `Strg+C` beendet den eigenen Testserver.

## Bewusst getrennt

- `public/`: alleiniger Webroot, enthält nur den neuen Shop und freigegebene Referenzassets.
- `data/products.json`: 19 Varianten aus 13 Gruppen; Namen und Preise aus der angegebenen Vercel-Seite, Preise als `price_cents` in ganzen Cent. Bilder separat über `image` / `detailImage`; Bestand ausdrücklich `UNCONFIRMED`.
- `data/catalog.json`: erweiterbarer Zusatzkatalog (`items` derzeit leer) und sechs recherchierte Systemeinträge. Alle sechs nicht bestellbar; kein Preis oder Bestand erfunden.
- `data/catalog-template.csv`: Import-/Nachpflegevorlage, keine erfundenen Materialartikel. Für diesen Stand `items` in JSON ergänzen; `published:true` macht Zusatzartikel im Katalog sichtbar, **nicht** automatisch kaufbar.
- `extensions/`: Mini-App-Anpassungen. Logo, Originalfarben, Originalschrift und Hauptlayout bleiben aus der Referenz erhalten.
- `evidence/source/` und `asset-cache/`: originaler Referenzsnapshot und benötigte Originalassets für reproduzierbaren Aufbau, niemals öffentlich ausliefern. Der private Rohsnapshot enthält auch die später ausgeschlossenen Produkte als Herkunftsbeleg.
- `runtime/test-requests.sqlite3`: lokale Testanfragen, nicht öffentlich abrufbar und nicht ins Auslieferungsarchiv aufnehmen.

## Übernommener Stand und Abweichungen

Maßgeblich ist **https://elements-labs-flagship.vercel.app/**, nicht die ältere GitHub-Pages-Seite oder der ältere lokale V5/V7-Checkout.

Technischer Stand der bisherigen Testversion: Sie enthält 19 Varianten; gegenüber der Referenz fehlen sechs Varianten aus zwei Produktgruppen. Dieser dokumentierte Ist-Zustand ist keine dauerhafte Sortimentsvorgabe. Über das gewünschte Sortiment entscheidet der aktuelle Kundenauftrag.

Die drei Referenzszenen mit ausdrücklich ausgeschlossener Produktwerbung wurden durch Original-Produktaufnahmen von BPC-157, TB-500 und Semaglutide ersetzt. Das ist eine Abweichung der bisherigen Umsetzung von pixelidentischer Übernahme, keine Vorgabe für künftige Kundenaufträge. Vollständiges 1:1 einschließlich aller Szenen wird deshalb **nicht** behauptet. Mobile Header, beschriftete Bodennavigation und Sicherheitsabstände sind auf eingebettete Nutzung angepasst. Der fehlerhafte Referenz-Suchpfad (SKU-Objekt statt Produktgruppen-Karte) wurde berichtigt.

## Bestellanfragen: kein Scheinerfolg

Der frühere reine Anzeige-Button wurde ersetzt. Eine Testanfrage erhält erst nach tatsächlicher SQLite-Speicherung eine `EL-TEST-...`-Referenz. Nachweise: `evidence/browser-request.json` und `evidence/http-readback.json`.

- **Kein Außenversand, keine Zahlung, kein Händlerauftrag.** Das steht auch sichtbar im Shop.
- Server prüft Produkt-ID, ganze Menge 1–99 und Preis aus seiner eigenen Konfiguration.
- Wiederholung derselben Anfrage ist idempotent; geänderte Inhalte mit gleicher Kennung werden abgelehnt.
- Fehleranzeige behauptet keine Speicherung. Zugriff auf Rohquellen, Testdatenbank, `.git` oder Verzeichnisse wird nicht erlaubt.
- `/api/config` und `/health` liefern nur den Teststatus. Es gibt keinen öffentlich lesbaren Anfragen-Endpunkt.

## Doppelkammer-Recherche

Sechs belegte System-/Plattformeinträge aus fünf Herstellerquellen: SCHOTT DC, Stevanato Dual Chamber Cartridges, Vetter V-LK, Vetter Lyo-Ject, Nipro Dual Chamber PFS und Ypsomed LyoTwist. **Karpule, Spritze, Gerät und Befüllung sind nicht dasselbe.**

Die konkrete Händlerware des Kunden wurde noch nicht identifiziert. Daher ist kein einziger Eintrag als „für euren Verkauf zugelassen“ bestätigt. Die Recherche stellt auch keine vollständige Weltmarkt- oder Rechtsregisterliste dar. Herstellertexte belegen die technischen Angebote, nicht automatisch eine befüllte Elements-Labs-Variante oder eine Lieferung durch den polnischen Händler. SCHOTT nennt eine nicht sterile Lieferform; Ypsomed nennt ein Lizenzangebot. Feldzitate und unmittelbare Gegenproben: `evidence/research/field-evidence.json`.

Die Herstellerrecherche dokumentiert technische Plattformen. Sie legt weder das Kundensortiment fest noch begründet sie eine pauschale Produktsperre. Produktangaben werden quellengetreu übernommen; fehlende Angaben bleiben als solche erkennbar.

## Telegram

Offizielles SDK von `https://telegram.org/js/telegram-web-app.js`: `ready`, `expand`, native Warenkorb-Schaltfläche, Zurück-Schaltfläche, Produkt-Startparameter und Safe Areas sind angebunden.

`evidence/telegram-simulator.json` ist **nur eine synthetische SDK-Schnittstellenprobe**, kein echter Telegram-Test. Echter Shop-Bot, Kontoanmeldung und isolierte HTTPS-Adresse fehlen noch. Ein fremder Hermes-/Community-Control-Bot wird dafür nicht umkonfiguriert.

Für eine später autorisierte echte Testinstanz kann der Server mit `--mode telegram --public-origin https://SEPARATE-TEST-ADRESSE` laufen. Dafür muss `ELEMENTS_TELEGRAM_BOT_TOKEN` vorher über einen sicheren lokalen Zugang bereitstehen; niemals im Chat, Frontend oder Git speichern. In diesem Modus wird Telegram-initData serverseitig per HMAC und Zeitlimit geprüft. Auch dieser Modus speichert derzeit **nur lokale Testanfragen** und sendet keine Händlernachricht.

## Prüfungen

```sh
python3 build.py
python3 -m unittest discover -s tests -v
node tests/test_frontend.cjs
```

Der Build verwendet den eingefrorenen Vercel-Snapshot und prüft explizite Transformationsanker; bei verändertem Aufbau scheitert er statt still einen falschen Stand zu erzeugen. Browser-Abnahme über `tests/browser_acceptance.py` in `browser_exec`; dokumentiert in `evidence/browser-acceptance.json`: sechs Ansichten (375/390/430/768/844 quer/1440), 19 Variantenseiten, Sprache DE/EN/FR, gültige und ungültige Batch-Suche, Ausschluss-Deep-Links, fehlerhaftes Hash-Fragment und provozierter Speicherfehler. HTML-/Bildprüfung und serverseitige Tests sind getrennt von der späteren echten Telegram-Abnahme.

## Nächste notwendige Schritte

1. Echtes Telegram-Konto für Shop-Einrichtung zugänglich machen und dedizierten Shop-Bot zuordnen. Keine Passwörter/Anmeldecodes im Chat.
2. Separate HTTPS-Testbereitstellung freigeben/zuordnen; Original-Vercel-Projekt bleibt unberührt.
3. Konkrete Doppelkammer-Artikel und gewünschte Varianten nach Kundenauftrag mit den dazugehörigen Produktdaten ergänzen.
4. Zusatz-Materialliste des Kunden in den vorbereiteten Katalog übernehmen, sobald sie vorliegt.

## Stand v2 (22.10., Qualitätsrunde)

- **Start Telegram-Testinstanz:** `Live-starten.command` (Fenster offen lassen). Baut neu, startet Tunnel, Server, Menüknopf und Bot `@ElementsLabsShop_bot`. Token nur aus `runtime/.env.elements`. Die Tunnel-Adresse wechselt bei jedem Start.
- **Bot:** `/start`, `/shop`, `/katalog`, `/hilfe`, Deep-Links `?start=p_<produkt>`; nach gespeicherter Testanfrage kommt eine Bestätigung nur in den eigenen Chat des Absenders (nicht an Händler).
- **Geschwindigkeit:** Bilder als WebP (63 MB → 2,2 MB), gzip, ETag, Cache-Header, Service-Worker, Lazy-Loading, `?v=`-Versionierung geänderter Bilder.
- **Telegram-nativ:** Haptik, Zurück-/Warenkorb-Knopf, Safe-Areas, Cloud-Sync von Warenkorb/Merkliste/Sprache, Teilen-Knopf, letzte Testanfragen im Warenkorb.
- **Katalog pflegen (ohne IT):** `katalog.csv` ausfüllen (Spalten Name;Kategorie;Beschreibung;Preis_EUR;Verfuegbarkeit;Bild), Bilder nach `katalog-bilder/`, dann `Katalog-aktualisieren.command`. Der Katalog ist im bisherigen Teststand als Anzeige + Merkliste implementiert; das ist keine dauerhafte Einschränkung des Kundenauftrags. Die 8 Muster-Einträge (neutrale Labor-/Lagerartikel) werden dabei ersetzt.
- **Doppelkammer:** sechs eigene Schema-Grafiken mit Elements-Labs-Logo (`tools/make_art.py`), keine Produktfotos, nicht bestellbar, keine Zulassungsaussage.
- **Tests:** `.venv-build/bin/python -m unittest discover -s tests`, `node tests/test_frontend.cjs`, Browser-Abnahme `tests/browser_acceptance.py`.
