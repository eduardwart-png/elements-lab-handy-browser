# ELEMENTS LABS — Telegram-Shop (Stand v3, 23.10.2026)

**Status: PARTIAL.** Gebaut, im Browser auf Mobil abgenommen und live geschaltet; die Bestellung im echten Telegram-Konto (signierte Identität) hat der Inhaber noch nicht ausgelöst.

## Was jetzt der Quelle entspricht
Quelle: `https://elements-labs-flagship.vercel.app/` (frisch gezogen, `evidence/reference-current/`, SHA-256 in `reference.json`, 118 Quell-Assets in `evidence/current-assets.json`).
- 25 Vials, 25 Doppelkammer-Ausführungen (eigene Render je Substanz, Quellpreise), Mehrweg-Pen (20,00 €, Quell-Render), vier Forschungsbereiche 9/5/9/2, gemeinsamer Warenkorb, Batch-Suche, Research Library, Qualitätsseiten.
- Herkunft je Datensatz: `evidence/current-product-provenance.json` (Preise sind Quellpreise, keine Verfügbarkeits- oder Freigabezusage).

## Ursache der schwachen Version vorher
Der Nachbau lief auf einem alten Snapshot (ohne `variants.js` und die Doppelkammer-/Pen-Bilder). Doppelkammer und Pen waren deshalb eigene Platzhalter-Grafiken ohne Preis. Behoben: Bau auf dem aktuellen Quellstand, Platzhalter entfernt.

## Beleg
- Tests: `evidence/current-unit.txt` (28 Tests OK), Node-Tests (Frontend, Warenkorb, Pending-Cart) grün.
- Browser (6 Größen, 51 Detailseiten, Suche, Sprachen, Fehlerpfade, Testanfrage gespeichert): `evidence/current-browser-acceptance.json`.
- Live: `evidence/current-live-deploy.json`, Wiederanlauf nach Tunnelausfall `evidence/current-live-recovery.json`.
- Unsignierte Anfrage wird abgelehnt (400), keine Speicherung: `evidence/current-public-negative.json`.

## Offen
Bestell-Tap mit echter Telegram-Identität (Fernsteuerung des Telegram-Fensters ist nicht möglich: Treiber-Sitzung beendet). Quick-Tunnel wechselt die Adresse bei jedem Neustart; Dauer-Adresse bräuchte eigenes Hosting.
