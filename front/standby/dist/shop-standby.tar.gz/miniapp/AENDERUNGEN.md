# Änderungen und Grenzen dieser Umsetzung

## Produktdateien

Neuer Arbeitsbereich: `~/Projekte-Mac/elements-lab-telegram/miniapp/` im bereits angelegten lokalen Zweig `telegram-miniapp`. Die älteren Dateien im Worktree-Stamm wurden nicht zur Shop-Auslieferung verwendet; allein `miniapp/public/` ist der Webroot.

Neu: `build.py`, `server.py`, `extensions/`, `data/products.json`, `data/catalog.json`, `data/catalog-template.csv`, `tests/`, `Shop-Vorschau.command`, `README.md`, `.gitignore`, erzeugte `public/`-Dateien, notwendiger `asset-cache/` und Roh-/Prüfbelege in `evidence/`.

Referenz-Live-Seite ausschließlich gelesen. Vier Kerndateien wurden nach dem Aufbau erneut abgerufen; ihre Hashes sind zum Eingangssnapshot identisch (`evidence/reference-readback.json`). Kein Push, kein Vercel-Deployment, kein Merge, keine Änderungen an Telegram-Bots und kein Versand von Nachrichten/Bestellungen vorgenommen.

## Kontinuität / Wissen

- Sessionmanifest über `hermes_session_bootstrap.py`, Session-ID `elements-telegram-20261022`, initialisiert und mit `miniapp/checkpoint.json` aktualisiert; Berichte in `miniapp/evidence/`.
- Bestehender Skill `dogfood`: Regeln zur exakten URL als Portierungsbaseline, spät geparsten Navigationsbeschriftungen, Toast-Gegenprobe und Abgrenzung SDK-Simulation/echter Telegram-Abnahme ergänzt.
- Bestehender Skill `obsidian`: korrekten `knowledge_sync`-stdin-/Python-API-Weg ergänzt; Warnung vor leerem stdin/`--help` in dieser Modulfassung.
- Wissen via `knowledge_sync` nach `ebos/knowledge/Elements_Labs_Telegram_Port_Praxis_20261022.md` und `~/Documents/Obsidian Vault/EBOS/Elements_Labs_Telegram_Port_Praxis_20261022.md`, jeweils zugehörige Receipts. Beide Notizen nach Erstellung eingelesen und Hashgleichheit geprüft. Das belegt diese Spiegelung, nicht eine universelle automatische Nutzung durch alle Agenten.
- Ein irrtümlicher `knowledge_sync --help`-Aufruf erzeugte zwei neue `Demo_Knowledge_20261022.md` samt zwei Receipts. Erstellungszeiten belegen, dass alle vier aus diesem Aufruf stammten. Diese vier eigenen Demoartefakte wurden wieder entfernt und ausschließlich in `evidence/accidental-demo-cleanup/` zur Nachvollziehbarkeit aufbewahrt. Keine älteren Wissensnotizen gelöscht. Der eBOS-Code wurde dafür nicht verändert.

## Testzustand

Der eigene lokale Testserver auf Port 8766 wurde nach Anpassungen einmal beendet und mit dem neuen Code gestartet. Nur lokale synthetische Testanfragen in `miniapp/runtime/test-requests.sqlite3`; weder ein Kundendatenbestand noch bestehende Hotel-/Community-Datenbanken wurden als Testziel benutzt.

Es wurde kein Autostart, Cronjob oder dauerhafter öffentlicher Dienst eingerichtet. Der laufende Vorschauserver ist ein Hilfsprozess dieser Sitzung; der Launcher und der Quellcode bleiben als startbares Artefakt erhalten.

## Bekannte offene Pflichten

Echter Telegram-Login, dedizierter Elements-Labs-Shop-Bot, freigegebene separate HTTPS-Testbereitstellung und Test innerhalb Telegrams. Die recherchierten Doppelkammer-Plattformen sind technische Referenzen; konkrete Artikel werden nach dem Kundenauftrag ausgearbeitet, ohne pauschale Produktsperre. Die spätere Zusatzmaterialliste ist als leerer nachpflegbarer Katalog vorbereitet.


## Stand v3 (23.10.2026)
- Bau auf aktuellem Quellstand (`evidence/reference-current/`, `asset-cache-current/`); `variants.js` der Quelle wird übernommen (IDs `dual-<id>`, `mehrweg-pen`; Quell-IDs `…-dual`, `reusable-pen` bleiben als Alias erreichbar).
- Doppelkammer und Pen mit Original-Renderings und Quellpreisen statt eigener Schemagrafiken (`tools/make_shop_art.py` erzeugt `data/shop-formats.json` aus der Quelle).
- Verbesserungen gegenüber der Quelle: Pen-Zuschnitt quer (`reusable-pen-wide`) für Karten, Warenkorb und Detail; Testhinweis statt „Demo-Checkout“; „Empfohlen zuerst“; Bottom-Navigation; Warenkorb bleibt beim Senden erhalten; Wiederanlauf-Supervisor (LaunchAgent).
- WebP-Qualität 92 (Raster bis 1600/1800 px).

## Stand v4 (24.10.2026) – Preislogik und 10er-Packungen
- `tools/apply_pricing.py` (idempotent) setzt Preise aus `data/reference-prices.json`: Einzel-Vial je Substanz an Wettbewerber-Anker (Semaglutide 15 mg 100 €, Tirzepatide 40 mg 150 €, Retatrutide 20 mg 120 €) bei 95 %, Doppelkammer = Vial + 10 €, Substanzen ohne Anker unverändert.
- 50 neue Positionen „10er-Packung“ (Vial und Doppelkammer): Katalogpreis = bester Einkaufspreis x 3, auf ,90 aufgerundet. Seite `#packs`, Tab „10er-Packs“, Block auf jeder Produktseite, Warenkorb/Server/Bot-Bestätigung kennen die Formate.
- `variants.js`: Doppelkammer-Preis kommt aus `shop-formats.json` (vorher Vial-Preis).
- Einkaufspreise bleiben in `../preislisten/shop_costs.json`, nie in `data/`/`public/` (Test). Bericht `evidence/pricing-report.csv` (intern).
- Offen (Inhaberentscheidung): Versandpauschale 5 €, Zubehör-/Pen-Bundles, Dosen 15 mg Semaglutide / 40 mg Tirzepatide.

## Stand v5 (24.10.2026) – Marktpreise
- Einzel-Vial = Median der öffentlichen Online-Preise (`../preislisten/markt_preise.json`, 7 Shops, Stand 24.10.) x 0,875, auf ,90 abgerundet; mehr mg nie billiger. Doppelkammer = Markt-Vial x Pen-Aufschlag (Median Pen/Vial der Konkurrenz, 1,42) x 0,875, mindestens Vial + 10 €. 10er-Packungen unverändert 3 x Einkauf.
- Dünne Belege: Epithalon 50 mg (1 Anbieter), 5-Amino-1MQ, NAD+ 500 mg, BPC-157+TB-500 (2-3 Anbieter). Bericht intern: `evidence/pricing-report.csv`.

## Stand v6 (24.10.2026) – Komplettkatalog 10er-Packs aus dem Verkaufsblatt
- Quelle der 10er-Preise: `ELEMENTS_LABS_VERKAUFSBLATT.pdf` des Inhabers (bereits 3 x Basispreis), geparst nach `../preislisten/verkaufsblatt_parsed.json` (`parse_verkaufsblatt.py`), Namen/Bereiche in `tools/catalog_lines.py`. 238 Zeilen (124 Vial, 114 Doppelkammer) stehen exakt zum PDF-Preis im Shop: 49 über die Packungen der 25 Shop-Produkte, 189 als `data/catalog-packs.json` (nur Katalog, kein Produktbild). Dazu die Doppelkammer-Packung BPC-157+TB-500 (nicht im Blatt, 3 x Einkauf) = 239 Artikel.
- Shop: Seite `#packs` (Suche, Typ- und Bereichsfilter, je Substanz Vial- und Doppelkammer-Preis nebeneinander), Teaser auf der Startseite, Banner unter den Format-Tabs, Tab/Bottom-Nav „10er-Packs“.
- Einzelpreise: Vial unverändert marktbasiert; Doppelkammer (Pen) 12,5 % unter dem Markt-Pen-Aufschlag; Einzelpreis mindestens 1,2 x Stückpreis der 10er-Packung (angehoben: TB-500 Vial, BPC-157+TB-500 Vial, Selank/Semax Vial, MOTS-c 10 Dual, Selank/Semax Dual).
- Auffälligkeiten im Verkaufsblatt (unverändert übernommen): TB-500 10 mg Vial 635 € > Doppelkammer 510 €; mehrere Staffeln nicht aufsteigend (Tirzepatide 50 mg Dual 600 < 40 mg 730; Retatrutide 50 mg Dual 660 < 40 mg 770; Retatrutide 60 mg Dual 1.280 > 80 mg 990; Tirzepatide 60 mg Dual 840 gegenüber 50 mg 600); Namen „FRAG“, „KK37/LL375“ als HGH Fragment 176-191 bzw. LL-37 gedeutet.

## Stand v7 (24.10.2026) – 10er-Vial-Preise gegen den Markt
- Analyse `../preislisten/markt_10er.py` (Quellen: peptidehaus.de 10-Vial-Kits, qsc-eu.com 10-Vial-Kits, Stand 24.10.): Median aus 2 Quellen; bei 1 Quelle nur, wenn das Blatt mehr als das 1,5-Fache verlangt (dann Quelle +15 %); auf 5 € gerundet, nur gesenkt, Staffel aufsteigend geglättet. 10er-Doppelkammer unverändert (Inhaber: in Ordnung). Ergebnis `evidence/markt-10er-analyse.csv`.
- Bac. Water (3 ml 30 €, 10 ml 40 € je 10 Vials) liegt unter dem Markt (79-110 €) und bleibt.

## Stand v8 (24.10.2026) – Konditionen, Preisempfehlung, Shop im Fokus
- Konditionen (`data/terms.json`, Server `terms.py`, Frontend `extensions/terms.js`, Paritätstest `tests/test_terms.py`): Mindestbestellwert 500 €, Versandpauschale 80 € (inkl. Verpackung), Gratisversand ab 1.000 € (Fortschrittsbalken im Warenkorb), Mengenrabatt 5 % ab 2.500 € und 10 % ab 5.000 € (nur auf 10er-Packs mit `discount_ok`), Sammelbestellung ab 200 € ohne Versand (Lieferung gebündelt). Der Server erzwingt den Mindestwert (HTTP 422 `MIN_ORDER`); regionale Versandsätze sind nicht eingebaut (eine Pauschale, bis der Inhaber Sätze nennt).
- Preise 10er-Packs (`../preislisten/empfehlung.py` -> `preisempfehlung.json`, Preisebene in `tools/catalog_lines.py`): mindestens 3 x Einkauf (Ting, sichtbarer Preis), gedeckelt auf den Markt-Median (dann Marge unter 3 x, Zeilen im internen Bericht), Doppelkammer-Pack >= Vial-Pack + 15 %, Zehner-Preise. `discount_ok` nur bei >= 60 % Marge.
- Bot: großer Shop-Button zuerst, `/preisliste` und Inline-Button senden `data/preisliste.pdf` (nur Verkaufspreise), `setMyDescription` für den leeren Chat, Menüknopf „Shop öffnen“.
- Startseite: Hero führt zum Shop (10er-Packs, Einzelvials) statt Pen & Doppelkammer; Konditionen-Chips darunter. Abweichung von der Vorlage auf ausdrücklichen Wunsch des Inhabers.
- Preview-Abnahme läuft mit `server.py --relaxed-terms` (nur Test), echte Konditionen prüft ein eigener Abschnitt in `tests/browser_acceptance.py`.

## Stand v9 (24.10.2026) – Preisregeln final, Händlersicht, Design-Paket
- Preisregeln 10er-Packs (`../preislisten/empfehlung.py`): Ziel 3 x Ting-Einkauf bis zum Marktrahmen (Median der 10er-Kits, aufgerundet), harte Untergrenze 50 % Marge, alte Verkaufsliste ist Untergrenze (Hauptfokus GHK-Cu, 5-Amino-1MQ, Retatrutide ohne Ausnahme, sonst höchstens bis zum Marktrahmen), Händlermarge (Zwischenhändler verkauft 10 Einzelvials zum Markt-Median) mindestens 45 %, Doppelkammer >= Vial + 15 %, Zehner-Preise.
- Zeilen über dem Marktrahmen wegen zu hohem Einkauf stehen mit Ting-Zielpreis in der Verhandlungsliste (Ting-Preischeck, Abschnitt 3); Händlermarge je Shop-Produkt in Abschnitt 4.
- Kunden-Preisliste: Mengenrabatt-Ausnahmen mit „*“ (kein %-Zeichen mehr), Euro-Zeichen bündig.
- Design-Paket für René: `../preislisten/make_design_package.py` kopiert den Shop ohne Einkaufs-/Lieferantendaten, Preislogik, Zugangsdaten und Laufzeitdaten und prüft den Inhalt auf verbotene Begriffe; Anleitung `README_RENE.md`.


## Stand v10 (24.10.2026, Abschluss-Audit)
- `preislisten/empfehlung.py`: Staffelregel `STEP_MIN 0.97` (kleinere Dosis mindestens 3 % günstiger) auch für 10er-Packs; vier Doppelkammer-Zeilen (Tirzepatide 40/50, Retatrutide 40/50, 60/80, 80/100) und Vial BPC-157 + TB-500 10/20 mg verletzten sie. Fester Inhaberpreis Reta 20 mg = 420 € bleibt (Ausnahme gegen alte Liste 15 mg = 410 €, 2,4 %).
- Tests: `OwnerPriceRules.test_smaller_dose_is_at_least_three_percent_cheaper`, Zehnerregel ohne Toleranz (vorher „weniger als 12 Ausnahmen“). 62 Python-Tests grün.
- Nachgezogen: Kundenliste/Top-20/Ting-Check neu, Repo-Daten (`rene_sync.py push-data`), ZIP, Live-Neustart mit neuem `live.py` (Test-Bot erlaubt, Menü-Rücklesen mit Wiederholung).

## Stand v11 (24.10.2026, Sortiment komplett + Margenübersicht)
- Sortimentsergänzung: alles aus den Lieferantenlisten, was das Verkaufsblatt nicht enthielt, ist als 10er-Pack im Katalog (`preislisten/sortiment_ergaenzung.py` -> `sortiment_ergaenzung.json`, von `tools/catalog_lines.py` neben die jeweilige Substanz einsortiert). +102 Zeilen (101 Vial, 1 Doppelkammer), jetzt 340 Katalogzeilen / 341 Packs im Shop. Nur Zubehör (Essigsäure) bleibt draußen: verkäuflich ist allein Bac. Water.
- Einkaufszuordnung korrigiert (`preislisten/ting_check.py`): `canon()` schnitt Klammerzusätze ab, dadurch bekamen CJC-1295 mit/ohne DAC, CJC+Ipamorelin, Lipo-C 216/526 und Oxytocin-Qualitäten denselben Einkauf (Marge zu hoch). Jetzt exakte Namen + Alias-Tabelle (CagriSema, IGF-1 LR3 100 mcg, Melanotan, CJC+Ipamorelin), Fallback nur wenn eindeutig. 11 Einkaufspreise geändert, Verkaufspreise daraus neu berechnet.
- Tests: `tests/test_sortiment.py` (braucht die Preis-Umgebung, sonst übersprungen), `test_pricing` trennt Verkaufsblatt (238) und Ergänzung (102). 62 Tests grün.
- `preislisten/marge_pdf.py`: Margenübersicht (EK, VK, Marge je Produkt, 17 Seiten) -> Schreibtisch `3 FÜR EDDY (intern)`. `preislisten/pipeline_alles.sh` fährt Erzeuger, Tests, alle PDFs und Repo-Daten in einem Lauf.
- Offen: Einzelverkauf (eigene Produktseite mit Vial-Bild) nur für die 25 Vorlage-Produkte; weitere Dosen (z. B. Semaglutide 15 mg, Tirzepatide 40 mg einzeln) brauchen neue Etikett-Bilder.
